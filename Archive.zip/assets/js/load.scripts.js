var $ = jQuery.noConflict();

$.getScript("assets/js/jquery-migrate-1.2.1.min.js");
$.getScript("assets/bootstrap/js/bootstrap.min.js");
$.getScript("assets/js/smoothscroll.js");
$.getScript("assets/js/owl.carousel.min.js");
$.getScript("assets/js/bootstrap-select.min.js");
$.getScript("assets/js/icheck.min.js");
$.getScript("assets/js/jquery.hotkeys.js");
$.getScript("assets/js/baron.min.js");
$.getScript("assets/js/jquery.nouislider.all.min.js");
//$.getScript("assets/js/moment-with-locales.min.js");
$.getScript("assets/js/bootstrap-datepicker.js");